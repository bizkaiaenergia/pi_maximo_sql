using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CSharpSnaphot
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
//
// Global constants
//
   const long ONEMINUTE = 60;             // one minute in seconds
   const long ONEHOUR = 60 * ONEMINUTE;   // one hour in seconds
   const long ONEDAY = ONEHOUR * 24;      // one day in seconds
//
// Global Data
//
      PISDK.PISDK g_SDK;
      PISDKDlg.ApplicationObject g_SDKDlgAppObject;   // PISDK dialog app. object
     
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.TextBox textBox1;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.TextBox textBox2;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.TextBox textBox3;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.TextBox textBox4;
      private System.Windows.Forms.Button button1;
      private System.Windows.Forms.Button button2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.label1 = new System.Windows.Forms.Label();
         this.textBox1 = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.textBox2 = new System.Windows.Forms.TextBox();
         this.label3 = new System.Windows.Forms.Label();
         this.textBox3 = new System.Windows.Forms.TextBox();
         this.label4 = new System.Windows.Forms.Label();
         this.textBox4 = new System.Windows.Forms.TextBox();
         this.button1 = new System.Windows.Forms.Button();
         this.button2 = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(16, 8);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(88, 16);
         this.label1.TabIndex = 0;
         this.label1.Text = "Server:";
         // 
         // textBox1
         // 
         this.textBox1.Location = new System.Drawing.Point(120, 8);
         this.textBox1.Name = "textBox1";
         this.textBox1.Size = new System.Drawing.Size(160, 22);
         this.textBox1.TabIndex = 1;
         this.textBox1.Text = "";
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(16, 40);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(88, 16);
         this.label2.TabIndex = 2;
         this.label2.Text = "Tagname:";
         // 
         // textBox2
         // 
         this.textBox2.Location = new System.Drawing.Point(120, 40);
         this.textBox2.Name = "textBox2";
         this.textBox2.Size = new System.Drawing.Size(160, 22);
         this.textBox2.TabIndex = 3;
         this.textBox2.Text = "sinusoid";
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(16, 72);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(88, 16);
         this.label3.TabIndex = 4;
         this.label3.Text = "Timestamp:";
         // 
         // textBox3
         // 
         this.textBox3.Location = new System.Drawing.Point(120, 72);
         this.textBox3.Name = "textBox3";
         this.textBox3.ReadOnly = true;
         this.textBox3.Size = new System.Drawing.Size(160, 22);
         this.textBox3.TabIndex = 5;
         this.textBox3.Text = "";
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(16, 104);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(88, 16);
         this.label4.TabIndex = 6;
         this.label4.Text = "Value:";
         // 
         // textBox4
         // 
         this.textBox4.Location = new System.Drawing.Point(120, 104);
         this.textBox4.Name = "textBox4";
         this.textBox4.ReadOnly = true;
         this.textBox4.Size = new System.Drawing.Size(160, 22);
         this.textBox4.TabIndex = 7;
         this.textBox4.Text = "";
         // 
         // button1
         // 
         this.button1.Location = new System.Drawing.Point(8, 136);
         this.button1.Name = "button1";
         this.button1.Size = new System.Drawing.Size(120, 40);
         this.button1.TabIndex = 8;
         this.button1.Text = "Tag Search";
         this.button1.Click += new System.EventHandler(this.button1_Click);
         // 
         // button2
         // 
         this.button2.Location = new System.Drawing.Point(160, 136);
         this.button2.Name = "button2";
         this.button2.Size = new System.Drawing.Size(120, 40);
         this.button2.TabIndex = 9;
         this.button2.Text = "Get Value";
         this.button2.Click += new System.EventHandler(this.button2_Click);
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
         this.ClientSize = new System.Drawing.Size(292, 267);
         this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                      this.button2,
                                                                      this.button1,
                                                                      this.textBox4,
                                                                      this.label4,
                                                                      this.textBox3,
                                                                      this.label3,
                                                                      this.textBox2,
                                                                      this.label2,
                                                                      this.textBox1,
                                                                      this.label1});
         this.Name = "Form1";
         this.Text = "Snapshot Value";
         this.Load += new System.EventHandler(this.Form1_Load);
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
      
      private void Form1_Load(object sender, System.EventArgs e)
      {
//
// Create the SDK object here. That will give the program the 
//    benefits of caching of servers and points.
// Also create the PISDK Dialogs Application object so we can use
//    Tag Search.
//
         try {
            g_SDK = new PISDK.PISDKClass();
            g_SDKDlgAppObject = new PISDKDlg.ApplicationObjectClass();
            this.textBox1.Text = g_SDK.Servers.DefaultServer.Name;
        }
        catch (System.Runtime.InteropServices.COMException comExc)
        {
            MessageBox.Show(comExc.Message,comExc.ErrorCode + " Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation);
         };
      }
 
      private void button1_Click(object sender, System.EventArgs e) {
//
// Display the Tag Search dialog and fill out the form with the result
//
      PISDKDlg.TagSearch myTagSearch;           // PISDK Tag search display object
      PISDK._PointList myPointList;             // point list returned from tag search
      PISDKCommon.NamedValues nvsSelServers;    // Namedvalues collection of servers
      PISDKDlg.TagSearchOptions tsOptions;      // tag search dialog options
      object valInx;                            // Variant for index
      object strObject;                         // Variant for string

      myTagSearch = g_SDKDlgAppObject.TagSearch;
//
// Pass the server that is in textBox1 as a default.
// Only allow a single tag to be selected.
//
      nvsSelServers = new PISDKCommon.NamedValuesClass();
      strObject = textBox1.Text;
      nvsSelServers.Add(textBox1.Text,ref strObject);
      tsOptions = PISDKDlg.TagSearchOptions.tsoptSingleSelect;
      myPointList = myTagSearch.Show(nvsSelServers,tsOptions);
      if (0 != myPointList.Count) {
         valInx = 1;
//
// Get Server name
//
         textBox1.Text = myPointList.get_Item(ref valInx).Parent.Name;
//
// Get Tag name
//
         textBox2.Text = myPointList.get_Item(ref valInx).Name;
      };
      }

      private void button2_Click(object sender, System.EventArgs e) {
//
//  Get the snapshot value of the tag in textBox2 from the server in textBox1
//
      PISDK.Server myServer;     // server object from the name in textBox1
      PISDK.PIPoints myPoints;   // PIPoints collection of server
      PISDK.PIPoint snapPoint;   // point from the name in textBox2
      PISDK.PIValue myValue;     // snapshot value
   
      if (textBox1.Text.Equals("")) {
         MessageBox.Show("No server entered.","Error",MessageBoxButtons.OK,
            MessageBoxIcon.Exclamation);
      }else{
         if (textBox2.Text.Equals("")) {
            MessageBox.Show("No tag entered.","Error",MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation);
         }else{
            try {
               myServer = g_SDK.Servers[textBox1.Text];
               myPoints = myServer.PIPoints;
               snapPoint = myPoints[textBox2.Text];
               myValue = snapPoint.Data.Snapshot;
               textBox3.Text = myValue.TimeStamp.LocalDate.ToString();
//
// Check to see if we got a digital state back
//
               if (myValue.Value.GetType().IsCOMObject) {
                  PISDK.DigitalState myDigState;
                  myDigState = (PISDK.DigitalState) myValue.Value;
                  textBox4.Text = myDigState.Name;
               }else{
                  textBox4.Text = myValue.Value.ToString();
               };
/*               
               PISDK.PIValues oVals;
               PITimeServer.PITime startTime = new PITimeServer.PITimeClass();
               PITimeServer.PITime endTime = new PITimeServer.PITimeClass();
               
               endTime.SetToCurrent();
               startTime.UTCSeconds = endTime.UTCSeconds - ONEHOUR;
               oVals = snapPoint.Data.RecordedValues(startTime,endTime,PISDK.BoundaryTypeConstants.btAuto,"",
                                                     PISDK.FilteredViewConstants.fvShowFilteredState,
                                                     null);
               myValue = oVals[1];
               if (myValue.Value.GetType().IsCOMObject) {
                  PISDK.DigitalState myDigState;
                  myDigState = (PISDK.DigitalState) myValue.Value;
                  textBox4.Text = myDigState.Name;
               }else{
                  textBox4.Text = myValue.Value.ToString();
               };
*/               
            }catch (System.Runtime.InteropServices.COMException comExc) {
               MessageBox.Show(comExc.Message,comExc.ErrorCode + " Error",
                  MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            };
         };
      };
      }
	}
}
