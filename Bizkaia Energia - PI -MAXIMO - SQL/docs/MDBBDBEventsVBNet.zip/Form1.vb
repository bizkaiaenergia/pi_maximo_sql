Public Class Form1
    Inherits System.Windows.Forms.Form
'
'  This example shows how to sign up for and retrieve events for PIModule, PIBatch,
'  PIUnitBatch, and PITransferRecord database changes from VisualBasic.NET.
'
'  2003-May KEC>  Written
'  2003-May HT>   Create SrvPickList at runtime (use the interop assembly instead of COM control)
'
'===================================================
'
'  Global Variables
'
Dim g_PISDK As PISDK.PISDK                     ' PISDK object
Dim g_PIServer As PISDK.Server
Dim g_ModuleDBEventPipe As PISDK.EventPipe
Dim g_BatchDBEventPipe As PISDK.EventPipe
Dim g_TxRecDBEventPipe As PISDK.EventPipe
Dim g_UnitBatchEventPipe As PISDK.EventPipe
Dim g_OffClr As System.Drawing.Color
Dim g_OnClr As System.Drawing.Color
Dim g_NameCounter As Long
Dim g_UIDNameStr As String
Dim g_StartTimeNameStr As String
Friend WithEvents ServPickList1 As OSIsoft.PISDK.Controls.ServPickList
Dim g_RootModule As PISDK.PIModule

   ' View the region below to see how the SrvPickList is created at run-time
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents Button1 As System.Windows.Forms.Button
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents Label2 As System.Windows.Forms.Label
   Friend WithEvents panelMDB As System.Windows.Forms.Panel
   Friend WithEvents panelMDBFill As System.Windows.Forms.Panel
   Friend WithEvents panelBatchDB As System.Windows.Forms.Panel
   Friend WithEvents panelBatchDBFill As System.Windows.Forms.Panel
   Friend WithEvents panelTxRecDBFill As System.Windows.Forms.Panel
   Friend WithEvents panelTxRecDB As System.Windows.Forms.Panel
   Friend WithEvents panelUnitBatchFill As System.Windows.Forms.Panel
   Friend WithEvents panelUnitBatch As System.Windows.Forms.Panel
   Friend WithEvents lblModuleDBNbrEvent As System.Windows.Forms.Label
   Friend WithEvents lblBatchDBNbrEvent As System.Windows.Forms.Label
   Friend WithEvents lblTxRecDBNbrEvent As System.Windows.Forms.Label
   Friend WithEvents lblUnitBatchNbrEvent As System.Windows.Forms.Label
   Friend WithEvents btnClearOutput As System.Windows.Forms.Button
   Friend WithEvents btnTakeAll As System.Windows.Forms.Button
   Friend WithEvents chkModuleDB As System.Windows.Forms.CheckBox
   Friend WithEvents chkBatchDB As System.Windows.Forms.CheckBox
   Friend WithEvents chkTxRecDB As System.Windows.Forms.CheckBox
   Friend WithEvents chkUnitBatch As System.Windows.Forms.CheckBox
   Friend WithEvents btnGenMDBEvent As System.Windows.Forms.Button
   Friend WithEvents btnGenBDBEvent As System.Windows.Forms.Button
   Friend WithEvents btnGenTxRecDBEvent As System.Windows.Forms.Button
   Friend WithEvents btnGenUnitBatchEvent As System.Windows.Forms.Button
   Friend WithEvents txtOutput As System.Windows.Forms.TextBox
   Friend WithEvents Timer1 As System.Windows.Forms.Timer
   Friend WithEvents txtModuleDBMaxEvent As System.Windows.Forms.TextBox
   Friend WithEvents txtTxRecDBMaxEvent As System.Windows.Forms.TextBox
   Friend WithEvents txtUnitBatchMaxEvent As System.Windows.Forms.TextBox
   Friend WithEvents txtBatchDBMaxEvent As System.Windows.Forms.TextBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.components = New System.ComponentModel.Container
Me.Button1 = New System.Windows.Forms.Button
Me.btnTakeAll = New System.Windows.Forms.Button
Me.Label1 = New System.Windows.Forms.Label
Me.chkModuleDB = New System.Windows.Forms.CheckBox
Me.chkBatchDB = New System.Windows.Forms.CheckBox
Me.chkTxRecDB = New System.Windows.Forms.CheckBox
Me.chkUnitBatch = New System.Windows.Forms.CheckBox
Me.btnGenMDBEvent = New System.Windows.Forms.Button
Me.btnGenBDBEvent = New System.Windows.Forms.Button
Me.btnGenTxRecDBEvent = New System.Windows.Forms.Button
Me.btnGenUnitBatchEvent = New System.Windows.Forms.Button
Me.Label2 = New System.Windows.Forms.Label
Me.txtModuleDBMaxEvent = New System.Windows.Forms.TextBox
Me.txtBatchDBMaxEvent = New System.Windows.Forms.TextBox
Me.txtTxRecDBMaxEvent = New System.Windows.Forms.TextBox
Me.txtUnitBatchMaxEvent = New System.Windows.Forms.TextBox
Me.panelMDB = New System.Windows.Forms.Panel
Me.panelMDBFill = New System.Windows.Forms.Panel
Me.panelBatchDB = New System.Windows.Forms.Panel
Me.panelBatchDBFill = New System.Windows.Forms.Panel
Me.panelTxRecDBFill = New System.Windows.Forms.Panel
Me.panelTxRecDB = New System.Windows.Forms.Panel
Me.panelUnitBatchFill = New System.Windows.Forms.Panel
Me.panelUnitBatch = New System.Windows.Forms.Panel
Me.lblModuleDBNbrEvent = New System.Windows.Forms.Label
Me.lblBatchDBNbrEvent = New System.Windows.Forms.Label
Me.lblTxRecDBNbrEvent = New System.Windows.Forms.Label
Me.lblUnitBatchNbrEvent = New System.Windows.Forms.Label
Me.btnClearOutput = New System.Windows.Forms.Button
Me.txtOutput = New System.Windows.Forms.TextBox
Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
Me.ServPickList1 = New OSIsoft.PISDK.Controls.ServPickList
Me.SuspendLayout()
'
'Button1
'
Me.Button1.Location = New System.Drawing.Point(0, 0)
Me.Button1.Name = "Button1"
Me.Button1.Size = New System.Drawing.Size(75, 23)
Me.Button1.TabIndex = 0
'
'btnTakeAll
'
Me.btnTakeAll.Location = New System.Drawing.Point(432, 8)
Me.btnTakeAll.Name = "btnTakeAll"
Me.btnTakeAll.Size = New System.Drawing.Size(128, 40)
Me.btnTakeAll.TabIndex = 0
Me.btnTakeAll.Text = "Get Events"
'
'Label1
'
Me.Label1.Location = New System.Drawing.Point(240, 9)
Me.Label1.Name = "Label1"
Me.Label1.Size = New System.Drawing.Size(186, 61)
Me.Label1.TabIndex = 2
Me.Label1.Text = "Click on datbase check box to begin/end collection"
'
'chkModuleDB
'
Me.chkModuleDB.Location = New System.Drawing.Point(16, 72)
Me.chkModuleDB.Name = "chkModuleDB"
Me.chkModuleDB.Size = New System.Drawing.Size(96, 24)
Me.chkModuleDB.TabIndex = 3
Me.chkModuleDB.Text = "ModuleDB"
'
'chkBatchDB
'
Me.chkBatchDB.Location = New System.Drawing.Point(152, 72)
Me.chkBatchDB.Name = "chkBatchDB"
Me.chkBatchDB.Size = New System.Drawing.Size(104, 24)
Me.chkBatchDB.TabIndex = 4
Me.chkBatchDB.Text = "BatchDB"
'
'chkTxRecDB
'
Me.chkTxRecDB.Location = New System.Drawing.Point(288, 72)
Me.chkTxRecDB.Name = "chkTxRecDB"
Me.chkTxRecDB.Size = New System.Drawing.Size(144, 24)
Me.chkTxRecDB.TabIndex = 5
Me.chkTxRecDB.Text = "TransferRecordDB"
'
'chkUnitBatch
'
Me.chkUnitBatch.Location = New System.Drawing.Point(448, 72)
Me.chkUnitBatch.Name = "chkUnitBatch"
Me.chkUnitBatch.Size = New System.Drawing.Size(104, 24)
Me.chkUnitBatch.TabIndex = 6
Me.chkUnitBatch.Text = "PIUnitBatch"
'
'btnGenMDBEvent
'
Me.btnGenMDBEvent.Location = New System.Drawing.Point(16, 104)
Me.btnGenMDBEvent.Name = "btnGenMDBEvent"
Me.btnGenMDBEvent.Size = New System.Drawing.Size(88, 48)
Me.btnGenMDBEvent.TabIndex = 7
Me.btnGenMDBEvent.Text = "Generate Add Event"
'
'btnGenBDBEvent
'
Me.btnGenBDBEvent.Location = New System.Drawing.Point(152, 104)
Me.btnGenBDBEvent.Name = "btnGenBDBEvent"
Me.btnGenBDBEvent.Size = New System.Drawing.Size(88, 48)
Me.btnGenBDBEvent.TabIndex = 8
Me.btnGenBDBEvent.Text = "Generate Add Event"
'
'btnGenTxRecDBEvent
'
Me.btnGenTxRecDBEvent.Location = New System.Drawing.Point(288, 104)
Me.btnGenTxRecDBEvent.Name = "btnGenTxRecDBEvent"
Me.btnGenTxRecDBEvent.Size = New System.Drawing.Size(88, 48)
Me.btnGenTxRecDBEvent.TabIndex = 9
Me.btnGenTxRecDBEvent.Text = "Generate Add Event"
'
'btnGenUnitBatchEvent
'
Me.btnGenUnitBatchEvent.Location = New System.Drawing.Point(448, 104)
Me.btnGenUnitBatchEvent.Name = "btnGenUnitBatchEvent"
Me.btnGenUnitBatchEvent.Size = New System.Drawing.Size(88, 48)
Me.btnGenUnitBatchEvent.TabIndex = 10
Me.btnGenUnitBatchEvent.Text = "Generate Add Event"
'
'Label2
'
Me.Label2.Location = New System.Drawing.Point(16, 160)
Me.Label2.Name = "Label2"
Me.Label2.Size = New System.Drawing.Size(72, 17)
Me.Label2.TabIndex = 11
Me.Label2.Text = "Max:"
'
'txtModuleDBMaxEvent
'
Me.txtModuleDBMaxEvent.Location = New System.Drawing.Point(24, 192)
Me.txtModuleDBMaxEvent.Name = "txtModuleDBMaxEvent"
Me.txtModuleDBMaxEvent.Size = New System.Drawing.Size(80, 22)
Me.txtModuleDBMaxEvent.TabIndex = 12
Me.txtModuleDBMaxEvent.Text = "10000"
'
'txtBatchDBMaxEvent
'
Me.txtBatchDBMaxEvent.Location = New System.Drawing.Point(160, 192)
Me.txtBatchDBMaxEvent.Name = "txtBatchDBMaxEvent"
Me.txtBatchDBMaxEvent.Size = New System.Drawing.Size(80, 22)
Me.txtBatchDBMaxEvent.TabIndex = 13
Me.txtBatchDBMaxEvent.Text = "10000"
'
'txtTxRecDBMaxEvent
'
Me.txtTxRecDBMaxEvent.Location = New System.Drawing.Point(292, 192)
Me.txtTxRecDBMaxEvent.Name = "txtTxRecDBMaxEvent"
Me.txtTxRecDBMaxEvent.Size = New System.Drawing.Size(80, 22)
Me.txtTxRecDBMaxEvent.TabIndex = 14
Me.txtTxRecDBMaxEvent.Text = "10000"
'
'txtUnitBatchMaxEvent
'
Me.txtUnitBatchMaxEvent.Location = New System.Drawing.Point(452, 192)
Me.txtUnitBatchMaxEvent.Name = "txtUnitBatchMaxEvent"
Me.txtUnitBatchMaxEvent.Size = New System.Drawing.Size(80, 22)
Me.txtUnitBatchMaxEvent.TabIndex = 15
Me.txtUnitBatchMaxEvent.Text = "10000"
'
'panelMDB
'
Me.panelMDB.Location = New System.Drawing.Point(48, 224)
Me.panelMDB.Name = "panelMDB"
Me.panelMDB.Size = New System.Drawing.Size(24, 144)
Me.panelMDB.TabIndex = 16
'
'panelMDBFill
'
Me.panelMDBFill.Location = New System.Drawing.Point(48, 224)
Me.panelMDBFill.Name = "panelMDBFill"
Me.panelMDBFill.Size = New System.Drawing.Size(24, 144)
Me.panelMDBFill.TabIndex = 17
'
'panelBatchDB
'
Me.panelBatchDB.Location = New System.Drawing.Point(184, 224)
Me.panelBatchDB.Name = "panelBatchDB"
Me.panelBatchDB.Size = New System.Drawing.Size(24, 144)
Me.panelBatchDB.TabIndex = 18
'
'panelBatchDBFill
'
Me.panelBatchDBFill.Location = New System.Drawing.Point(184, 224)
Me.panelBatchDBFill.Name = "panelBatchDBFill"
Me.panelBatchDBFill.Size = New System.Drawing.Size(24, 144)
Me.panelBatchDBFill.TabIndex = 19
'
'panelTxRecDBFill
'
Me.panelTxRecDBFill.Location = New System.Drawing.Point(320, 224)
Me.panelTxRecDBFill.Name = "panelTxRecDBFill"
Me.panelTxRecDBFill.Size = New System.Drawing.Size(24, 144)
Me.panelTxRecDBFill.TabIndex = 21
'
'panelTxRecDB
'
Me.panelTxRecDB.Location = New System.Drawing.Point(320, 224)
Me.panelTxRecDB.Name = "panelTxRecDB"
Me.panelTxRecDB.Size = New System.Drawing.Size(24, 144)
Me.panelTxRecDB.TabIndex = 20
'
'panelUnitBatchFill
'
Me.panelUnitBatchFill.Location = New System.Drawing.Point(480, 224)
Me.panelUnitBatchFill.Name = "panelUnitBatchFill"
Me.panelUnitBatchFill.Size = New System.Drawing.Size(24, 144)
Me.panelUnitBatchFill.TabIndex = 23
'
'panelUnitBatch
'
Me.panelUnitBatch.Location = New System.Drawing.Point(480, 224)
Me.panelUnitBatch.Name = "panelUnitBatch"
Me.panelUnitBatch.Size = New System.Drawing.Size(24, 144)
Me.panelUnitBatch.TabIndex = 22
'
'lblModuleDBNbrEvent
'
Me.lblModuleDBNbrEvent.Location = New System.Drawing.Point(32, 376)
Me.lblModuleDBNbrEvent.Name = "lblModuleDBNbrEvent"
Me.lblModuleDBNbrEvent.Size = New System.Drawing.Size(64, 24)
Me.lblModuleDBNbrEvent.TabIndex = 24
Me.lblModuleDBNbrEvent.Text = "0"
'
'lblBatchDBNbrEvent
'
Me.lblBatchDBNbrEvent.Location = New System.Drawing.Point(168, 376)
Me.lblBatchDBNbrEvent.Name = "lblBatchDBNbrEvent"
Me.lblBatchDBNbrEvent.Size = New System.Drawing.Size(64, 24)
Me.lblBatchDBNbrEvent.TabIndex = 25
Me.lblBatchDBNbrEvent.Text = "0"
'
'lblTxRecDBNbrEvent
'
Me.lblTxRecDBNbrEvent.Location = New System.Drawing.Point(300, 376)
Me.lblTxRecDBNbrEvent.Name = "lblTxRecDBNbrEvent"
Me.lblTxRecDBNbrEvent.Size = New System.Drawing.Size(64, 24)
Me.lblTxRecDBNbrEvent.TabIndex = 26
Me.lblTxRecDBNbrEvent.Text = "0"
'
'lblUnitBatchNbrEvent
'
Me.lblUnitBatchNbrEvent.Location = New System.Drawing.Point(460, 376)
Me.lblUnitBatchNbrEvent.Name = "lblUnitBatchNbrEvent"
Me.lblUnitBatchNbrEvent.Size = New System.Drawing.Size(64, 24)
Me.lblUnitBatchNbrEvent.TabIndex = 27
Me.lblUnitBatchNbrEvent.Text = "0"
'
'btnClearOutput
'
Me.btnClearOutput.Location = New System.Drawing.Point(552, 352)
Me.btnClearOutput.Name = "btnClearOutput"
Me.btnClearOutput.Size = New System.Drawing.Size(80, 40)
Me.btnClearOutput.TabIndex = 28
Me.btnClearOutput.Text = "Clear Output"
'
'txtOutput
'
Me.txtOutput.Location = New System.Drawing.Point(16, 400)
Me.txtOutput.Multiline = True
Me.txtOutput.Name = "txtOutput"
Me.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
Me.txtOutput.Size = New System.Drawing.Size(616, 168)
Me.txtOutput.TabIndex = 29
'
'Timer1
'
Me.Timer1.Enabled = True
Me.Timer1.Interval = 2000
'
'ServPickList1
'
Me.ServPickList1.ConnectOnSelect = False
Me.ServPickList1.Location = New System.Drawing.Point(24, 16)
Me.ServPickList1.Name = "ServPickList1"
Me.ServPickList1.SelectedServerName = "kendual"
Me.ServPickList1.ShowCollectiveMembers = False
Me.ServPickList1.Size = New System.Drawing.Size(128, 31)
Me.ServPickList1.TabIndex = 30
'
'Form1
'
Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
Me.ClientSize = New System.Drawing.Size(771, 629)
Me.Controls.Add(Me.ServPickList1)
Me.Controls.Add(Me.txtOutput)
Me.Controls.Add(Me.txtUnitBatchMaxEvent)
Me.Controls.Add(Me.txtTxRecDBMaxEvent)
Me.Controls.Add(Me.txtBatchDBMaxEvent)
Me.Controls.Add(Me.txtModuleDBMaxEvent)
Me.Controls.Add(Me.btnClearOutput)
Me.Controls.Add(Me.lblUnitBatchNbrEvent)
Me.Controls.Add(Me.lblTxRecDBNbrEvent)
Me.Controls.Add(Me.lblBatchDBNbrEvent)
Me.Controls.Add(Me.lblModuleDBNbrEvent)
Me.Controls.Add(Me.Label2)
Me.Controls.Add(Me.btnGenUnitBatchEvent)
Me.Controls.Add(Me.btnGenTxRecDBEvent)
Me.Controls.Add(Me.btnGenBDBEvent)
Me.Controls.Add(Me.btnGenMDBEvent)
Me.Controls.Add(Me.chkUnitBatch)
Me.Controls.Add(Me.chkTxRecDB)
Me.Controls.Add(Me.chkBatchDB)
Me.Controls.Add(Me.chkModuleDB)
Me.Controls.Add(Me.Label1)
Me.Controls.Add(Me.btnTakeAll)
Me.Controls.Add(Me.panelMDBFill)
Me.Controls.Add(Me.panelBatchDBFill)
Me.Controls.Add(Me.panelTxRecDBFill)
Me.Controls.Add(Me.panelUnitBatchFill)
Me.Controls.Add(Me.panelTxRecDB)
Me.Controls.Add(Me.panelBatchDB)
Me.Controls.Add(Me.panelMDB)
Me.Controls.Add(Me.panelUnitBatch)
Me.Name = "Form1"
Me.Text = "Form1"
Me.ResumeLayout(False)
Me.PerformLayout()

End Sub

#End Region


Private Sub WaitCursor()
      System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
End Sub

Private Sub NormalCursor()
      System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
End Sub

Private Sub ServerConnect()
On Error GoTo EH
   g_PIServer = ServPickList1.SelectedServer
   If Not g_PIServer.Connected Then
      Dim cnxn As New PISDKDlg.Connections()
      cnxn.Login(g_PIServer)
      If ((Err.Number <> 0) And Err.Number <> (PISDK.PISDKErrorConstants.pseSERVERIDMISMATCH)) Then
         MessageBox.Show(Err.Description)
         Exit Sub
      End If
'
'  We need these attribute names to retieve data from the event NamedValues collection.
'     Get them once.
'
      g_UIDNameStr = g_PIServer.PIModuleDB.AttributeName(PISDK.ModuleBatchDBAttributeConstants.mbaUID)
      g_StartTimeNameStr = g_PIServer.PIModuleDB.AttributeName(PISDK.ModuleBatchDBAttributeConstants.mbaStartTime)
'
'  Create a root module to add our modules under. Make it a unit so we can use it for UnitBatch events
'
      g_RootModule = g_PIServer.PIModuleDB.PIModules.Add(GenUniqueName("MDBEventTestRoot"))
      g_RootModule.IsPIUnit = True
   End If
Exit Sub
EH:
MessageBox.Show(Err.Description)
End Sub

Function GenUniqueName(ByVal prefix As String) As String

Dim uniqueName As String
Dim curTim As New PITimeServer.PITimeClass()
Dim curDate As Date

   curTim.SetToCurrent()
   curDate = curTim.LocalDate
   uniqueName = Format(curDate, "yymmddhhmmss") & "-" & g_NameCounter
   g_NameCounter = g_NameCounter + 1   ' increment this to make sure we get unique ID's
   GenUniqueName = prefix & uniqueName

End Function

Private Sub AddText(ByVal newText As String)
    txtOutput.AppendText(newText & vbCrLf)
    txtOutput.ScrollToCaret()
End Sub

Private Sub chkModuleDB_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkModuleDB.CheckedChanged
'
'  ModuleDB
'
   WaitCursor()
   If (chkModuleDB.Checked) Then
      ServerConnect()
      g_ModuleDBEventPipe = g_PIServer.PIModuleDB.EventPipe
      g_ModuleDBEventPipe.MaxCount = CInt(txtModuleDBMaxEvent.Text)
   Else
      g_ModuleDBEventPipe = Nothing       ' turn off collection
   End If
   ClearModuleDB()
   NormalCursor()
End Sub

Private Sub chkBatchDB_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkBatchDB.CheckedChanged
'
'  BatchDB
'
   WaitCursor()
   If (chkBatchDB.Checked) Then
      ServerConnect()
      g_BatchDBEventPipe = g_PIServer.PIBatchDB.EventPipe
      g_BatchDBEventPipe.MaxCount = CInt(txtBatchDBMaxEvent.Text)
   Else
      g_BatchDBEventPipe = Nothing       ' turn off collection
   End If
   ClearBatchDB()
   NormalCursor()
End Sub

Private Sub chkTxRecDB_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkTxRecDB.CheckedChanged
'
'  TxRecDB
'
   WaitCursor()
   If (chkTxRecDB.Checked) Then
      ServerConnect()
      g_TxRecDBEventPipe = g_PIServer.PIBatchDB.PITransferRecordDB.EventPipe
      g_TxRecDBEventPipe.MaxCount = CInt(txtTxRecDBMaxEvent.Text)
   Else
      g_TxRecDBEventPipe = Nothing       ' turn off collection
   End If
   ClearTxRecDB()
   NormalCursor()
End Sub

Private Sub chkUnitBatch_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkUnitBatch.CheckedChanged
'
'  UnitBatch
'
   WaitCursor()
   If (chkUnitBatch.Checked) Then
      ServerConnect()
      g_UnitBatchEventPipe = g_RootModule.EventPipe
      g_UnitBatchEventPipe.MaxCount = CInt(txtUnitBatchMaxEvent.Text)
   Else
      g_UnitBatchEventPipe = Nothing       ' turn off collection
   End If
   ClearUnitBatch()
   NormalCursor()

End Sub

Private Sub btnTakeAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTakeAll.Click
   Dim curPIEv As PISDK.PIEventObject
   Dim curMsg As String
   Dim nbrItem As Long
   Dim itemInx As Long
   Dim dataNVS As PISDKCommon.NamedValues
   Dim nvUID As PISDKCommon.NamedValue          ' NamedValue that holds the UID of the object
   Dim nvStartTime As PISDKCommon.NamedValue    ' NamedValue that holds the start time of the object
   Dim IPGR As PISDK.IPIGlobalRestorer          ' interface to get global restorer object
   Dim restorer As PISDKCommon.PIGlobalRestorer ' global restorer object
   Dim errors As PISDKCommon.PIErrors           ' error collection to hold any errors
   Dim myMod As PISDK.PIModule                  ' module to restore
   Dim batch As PISDK.PIBatch                   ' pibatch to restore
   Dim txRec As PISDK.PITransferRecord          ' pitransferrecord to restore
   Dim unitBatch As PISDK.PIUnitBatch           ' piunitbatch to restore

   On Error GoTo EH
   WaitCursor()
'
'  Get global restorer from PISDK object
'
   IPGR = CType(g_PISDK, PISDK.IPIGlobalRestorer)
   restorer = IPGR.Restorer
'
'  PIModule DB
'
   If (Not g_ModuleDBEventPipe Is Nothing) Then
      nbrItem = g_ModuleDBEventPipe.Count
'
'  Get each event and write its data to the output box
'
      For itemInx = 1 To nbrItem
         curPIEv = g_ModuleDBEventPipe.Take
         dataNVS = curPIEv.EventData
         nvUID = dataNVS.Item(g_UIDNameStr)
         curMsg = "PIModuleDB> Type: " & ActionName(curPIEv.Action) & " UID: " & nvUID.Value
         AddText(curMsg)
'
'  Restore object from persistence string unless action type is Delete
'
         If (curPIEv.Action = PISDK.EventActionConstants.eaDelete) Then
            curMsg = "     Passivation String: " & curPIEv.PassivationString
            AddText(curMsg)
         Else
            myMod = restorer.RestoreObject(curPIEv.PassivationString)
            curMsg = "     Restored Module Name: " & myMod.Name
            AddText(curMsg)
         End If
      Next
   End If
'
'  PIBatch DB
'
   If (Not g_BatchDBEventPipe Is Nothing) Then
      nbrItem = g_BatchDBEventPipe.Count
'
'  Get each event and write its data to the output box
'
      For itemInx = 1 To nbrItem
         curPIEv = g_BatchDBEventPipe.Take
         dataNVS = curPIEv.EventData
         nvUID = dataNVS.Item(g_UIDNameStr)
         curMsg = "PIBatchDB> Type: " & ActionName(curPIEv.Action) & " UID: " & nvUID.Value
         AddText(curMsg)
'
'  Restore object from persistence string unless action type is Delete
'
         If (curPIEv.Action = PISDK.EventActionConstants.eaDelete) Then
            curMsg = "     Passivation String: " & curPIEv.PassivationString
            AddText(curMsg)
         Else
            batch = restorer.RestoreObject(curPIEv.PassivationString)
            curMsg = "     Restored Batch BatchID: " & batch.BatchID & " StartTime: " & batch.StartTime.LocalDate
            AddText(curMsg)
         End If
      Next
   End If
'
'  TransferRecord DB
'
   If (Not g_TxRecDBEventPipe Is Nothing) Then
      nbrItem = g_TxRecDBEventPipe.Count
'
'  Get each event and write its data to the output box
'
      For itemInx = 1 To nbrItem
         curPIEv = g_TxRecDBEventPipe.Take
         dataNVS = curPIEv.EventData
         nvUID = dataNVS.Item(g_UIDNameStr)
         curMsg = "TransferRecordDB> Type: " & ActionName(curPIEv.Action) & " UID: " & nvUID.Value
         AddText(curMsg)
'
'  Restore object from persistence string unless action type is Delete
'
         If (curPIEv.Action = PISDK.EventActionConstants.eaDelete) Then
            curMsg = "     Passivation String: " & curPIEv.PassivationString
            AddText(curMsg)
         Else
            txRec = restorer.RestoreObject(curPIEv.PassivationString)
            curMsg = "     Restored TransferRecord UID: " & txRec.UniqueID & " StartTime: " & txRec.StartTime.LocalDate
            AddText(curMsg)
         End If
      Next
   End If
'
'  PIUnitBatch
'
   If (Not g_UnitBatchEventPipe Is Nothing) Then
      nbrItem = g_UnitBatchEventPipe.Count
'
'  Get each event and write its data to the output box
'
      For itemInx = 1 To nbrItem
         curPIEv = g_UnitBatchEventPipe.Take
         dataNVS = curPIEv.EventData
         nvUID = dataNVS.Item(g_UIDNameStr)
         curMsg = "PIUnitBatch> Type: " & ActionName(curPIEv.Action) & " UID: " & nvUID.Value
         AddText(curMsg)
'
'  Restore object from persistence string unless action type is Delete
'
         If (curPIEv.Action = PISDK.EventActionConstants.eaDelete) Then
            curMsg = "     Passivation String: " & curPIEv.PassivationString
            AddText(curMsg)
         Else
            unitBatch = restorer.RestoreObject(curPIEv.PassivationString)
            curMsg = "     Restored UnitBatch BatchID: " & unitBatch.BatchID & " StartTime: " & unitBatch.StartTime.LocalDate
            AddText(curMsg)
         End If
      Next
   End If

   UpdateDisplay() ' update the display
   NormalCursor()
Exit Sub
EH:
   NormalCursor()
   MessageBox.Show(Err.Description)
End Sub

Private Sub btnGenMDBEvent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenMDBEvent.Click
   WaitCursor()
   g_RootModule.PIModules.Add(GenUniqueName("MDBEventTest"))   ' Add a module below the root
   UpdateDisplay() ' update the display
   NormalCursor()
End Sub

Private Sub btnGenBDBEvent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenBDBEvent.Click
   Dim startTime As New PITimeServer.PITimeClass()
   Dim endTime As New PITimeServer.PITimeClass()

   WaitCursor()
   endTime.SetToCurrent()
   startTime.UTCSeconds = endTime.UTCSeconds - 1     ' one second batch
   g_PIServer.PIBatchDB.Add(GenUniqueName("BDBEventTest"), "Product", "Recipe", startTime, endTime)
   UpdateDisplay() ' update the display
   NormalCursor()
End Sub

Private Sub btnGenTxRecDBEvent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenTxRecDBEvent.Click
   Dim startTime As New PITimeServer.PITimeClass()
   Dim endTime As New PITimeServer.PITimeClass()

   WaitCursor()
   endTime.SetToCurrent()
   startTime.UTCSeconds = endTime.UTCSeconds - 1     ' one second transfer
'
'  Use root module for source and destination
'
   g_PIServer.PIBatchDB.PITransferRecordDB.Add(g_RootModule, g_RootModule, startTime, endTime)
   UpdateDisplay() ' update the display
   NormalCursor()
End Sub

Private Sub btnGenUnitBatchEvent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenUnitBatchEvent.Click
   Dim startTime As New PITimeServer.PITimeClass()
   Dim endTime As New PITimeServer.PITimeClass()

   On Error GoTo eH
   WaitCursor()
   endTime.SetToCurrent()
   startTime.UTCSeconds = endTime.UTCSeconds - 1     ' one second batch
'
'  Use root module
'
   Dim unitBatch As PISDK.PIUnitBatch
   unitBatch = g_RootModule.AddPIUnitBatch(GenUniqueName("UnitBatch>"), "Product1", startTime, endTime)

   AddText("PIUnitBatch>Add   ")
   AddText("     ModuleUID: " & g_RootModule.UniqueID)
   AddText("    UnitBatchUID: " & unitBatch.UniqueID)
   AddText("    StartTimeUTC: " & startTime.UTCSeconds)

   UpdateDisplay() ' update the display
   NormalCursor()
   Exit Sub
eH:
   NormalCursor()
   If (Err.Number = PISDK.PISDKErrorConstants.pseSERVERDBADDFAIL) Then
      MessageBox.Show("Don't click faster than 1/second when adding UnitBatches")
   End If
End Sub

Private Sub btnClearOutput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearOutput.Click
   txtOutput.Text = ""
End Sub

Private Sub UpdateDisplay()
'   update bar display
   Dim maxCount As Single
   Dim currentCount As Single
   Dim dblBarHeight As Single
   Dim dblPercentFull As Single
   Dim arrRGB(5) As System.Drawing.Color
   Dim colorIndex As Long

   arrRGB(0) = System.Drawing.Color.FromArgb(0, 255, 0)
   arrRGB(1) = System.Drawing.Color.FromArgb(128, 255, 0)
   arrRGB(2) = System.Drawing.Color.FromArgb(255, 255, 0)
   arrRGB(3) = System.Drawing.Color.FromArgb(255, 128, 0)
   arrRGB(4) = System.Drawing.Color.FromArgb(255, 0, 0)
'
'  Check all active event pipes
'
'  PIModule DB
'
   If (Not g_ModuleDBEventPipe Is Nothing) Then
      maxCount = g_ModuleDBEventPipe.MaxCount
      currentCount = g_ModuleDBEventPipe.Count
      dblPercentFull = currentCount / maxCount
   Else
      currentCount = 0.0
      dblPercentFull = 0.0
   End If
   If dblPercentFull <= 0.2 Then
      colorIndex = 0
   Else
      If dblPercentFull <= 0.4 Then
         colorIndex = 1
      Else
         If dblPercentFull <= 0.6 Then
            colorIndex = 2
         Else
            If dblPercentFull <= 0.8 Then
               colorIndex = 3
            Else
               colorIndex = 4
            End If
         End If
      End If
   End If
   panelMDBFill.BackColor = arrRGB(colorIndex)
   dblBarHeight = dblPercentFull * panelMDB.Height
   panelMDBFill.Left = panelMDB.Left
   panelMDBFill.Width = panelMDB.Width
   panelMDBFill.Height = dblBarHeight
   panelMDBFill.Top = panelMDB.Top + (panelMDB.Height - panelMDBFill.Height)
   lblModuleDBNbrEvent.Text = CStr(currentCount)
'
'  PIBatch DB
'
   If (Not g_BatchDBEventPipe Is Nothing) Then
      maxCount = g_BatchDBEventPipe.MaxCount
      currentCount = g_BatchDBEventPipe.Count
      dblPercentFull = currentCount / maxCount
   Else
      currentCount = 0.0
      dblPercentFull = 0.0
   End If
   If dblPercentFull <= 0.2 Then
      colorIndex = 0
   Else
      If dblPercentFull <= 0.4 Then
         colorIndex = 1
      Else
         If dblPercentFull <= 0.6 Then
            colorIndex = 2
         Else
            If dblPercentFull <= 0.8 Then
               colorIndex = 3
            Else
               colorIndex = 4
            End If
         End If
      End If
   End If
   panelBatchDBFill.BackColor = arrRGB(colorIndex)
   dblBarHeight = dblPercentFull * panelBatchDB.Height
   panelBatchDBFill.Left = panelBatchDB.Left
   panelBatchDBFill.Width = panelBatchDB.Width
   panelBatchDBFill.Height = dblBarHeight
   panelBatchDBFill.Top = panelBatchDB.Top + (panelBatchDB.Height - panelBatchDBFill.Height)
   lblBatchDBNbrEvent.Text = CStr(currentCount)
'
'  PITransferRecord DB
'
   If (Not g_TxRecDBEventPipe Is Nothing) Then
      maxCount = g_TxRecDBEventPipe.MaxCount
      currentCount = g_TxRecDBEventPipe.Count
      dblPercentFull = currentCount / maxCount
   Else
      currentCount = 0.0
      dblPercentFull = 0.0
   End If
   If dblPercentFull <= 0.2 Then
      colorIndex = 0
   Else
      If dblPercentFull <= 0.4 Then
         colorIndex = 1
      Else
         If dblPercentFull <= 0.6 Then
            colorIndex = 2
         Else
            If dblPercentFull <= 0.8 Then
               colorIndex = 3
            Else
               colorIndex = 4
            End If
         End If
      End If
   End If
   panelTxRecDBFill.BackColor = arrRGB(colorIndex)
   dblBarHeight = dblPercentFull * panelTxRecDB.Height
   panelTxRecDBFill.Left = panelTxRecDB.Left
   panelTxRecDBFill.Width = panelTxRecDB.Width
   panelTxRecDBFill.Height = dblBarHeight
   panelTxRecDBFill.Top = panelTxRecDB.Top + (panelTxRecDB.Height - panelTxRecDBFill.Height)
   lblTxRecDBNbrEvent.Text = CStr(currentCount)
'
'  PIUnitBatch
'
   If (Not g_UnitBatchEventPipe Is Nothing) Then
      maxCount = g_UnitBatchEventPipe.MaxCount
      currentCount = g_UnitBatchEventPipe.Count
      dblPercentFull = currentCount / maxCount
   Else
      currentCount = 0.0
      dblPercentFull = 0.0
   End If
   If dblPercentFull <= 0.2 Then
      colorIndex = 0
   Else
      If dblPercentFull <= 0.4 Then
         colorIndex = 1
      Else
         If dblPercentFull <= 0.6 Then
            colorIndex = 2
         Else
            If dblPercentFull <= 0.8 Then
               colorIndex = 3
            Else
               colorIndex = 4
            End If
         End If
      End If
   End If
   panelUnitBatchFill.BackColor = arrRGB(colorIndex)
   dblBarHeight = dblPercentFull * panelUnitBatch.Height
   panelUnitBatchFill.Left = panelUnitBatch.Left
   panelUnitBatchFill.Width = panelUnitBatch.Width
   panelUnitBatchFill.Height = dblBarHeight
   panelUnitBatchFill.Top = panelUnitBatch.Top + (panelUnitBatch.Height - panelUnitBatchFill.Height)
   lblUnitBatchNbrEvent.Text = CStr(currentCount)
End Sub

Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
   UpdateDisplay() ' update the display
End Sub

Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
'
'  Get PISDK object once on form load so we can cache server connections
'
   g_PISDK = New PISDK.PISDK()
   ClearDisplay()
   txtModuleDBMaxEvent.Text = "10"
   txtBatchDBMaxEvent.Text = "20"
   txtTxRecDBMaxEvent.Text = "15"
   txtUnitBatchMaxEvent.Text = "25"
   g_OffClr = System.Drawing.Color.FromArgb(0, 0, 0)     ' black for off
   g_OnClr = System.Drawing.Color.FromArgb(128, 128, 128) ' gray
End Sub

Private Function ActionName(ByRef action As PISDK.EventActionConstants) As String
   If (action = PISDK.EventActionConstants.eaAdd) Then
      ActionName = "Add"
   ElseIf (action = PISDK.EventActionConstants.eaDelete) Then
      ActionName = "Delete"
   ElseIf (action = PISDK.EventActionConstants.eaEdit) Then
      ActionName = "Edit"
   ElseIf (action = PISDK.EventActionConstants.eaUpdate) Then
      ActionName = "Update"
   Else
      ActionName = "UNKNOWN"
   End If
End Function

Private Sub ClearModuleDB()
'
'  ModuleDB
'
   If (chkModuleDB.Checked) Then
      panelMDB.BackColor = g_OnClr
   Else
      panelMDB.BackColor = g_OffClr
   End If
   UpdateDisplay() ' update the display
End Sub

Private Sub ClearBatchDB()
'
'  BatchDB
'
   If (chkBatchDB.Checked) Then
      panelBatchDB.BackColor = g_OnClr
   Else
      panelBatchDB.BackColor = g_OffClr
   End If
   UpdateDisplay() ' update the display
End Sub

Private Sub ClearTxRecDB()
'
'  TransferRecordDB
'
   If (chkTxRecDB.Checked) Then
      panelTxRecDB.BackColor = g_OnClr
   Else
      panelTxRecDB.BackColor = g_OffClr
   End If
   UpdateDisplay() ' update the display
End Sub

Private Sub ClearUnitBatch()
'
'  PIUnitBatch
'
   If (chkUnitBatch.Checked) Then
      panelUnitBatch.BackColor = g_OnClr
   Else
      panelUnitBatch.BackColor = g_OffClr
   End If
   UpdateDisplay() ' update the display
End Sub

Private Sub ClearDisplay()
   ClearModuleDB()
   ClearBatchDB()
   ClearTxRecDB()
   ClearUnitBatch()
End Sub
End Class
